﻿from turtle import *

def polygone_regulier(longueur, aretes):
    """
        trace un polygone régulier
        :param longueur: (int) longueur d'un côté
        :param aretes: (int) nombre de côtés
    """
