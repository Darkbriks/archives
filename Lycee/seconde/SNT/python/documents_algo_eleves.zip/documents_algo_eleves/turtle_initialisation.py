﻿from turtle import * #importation du module turtle

forward(100)    #trace un segment de 100 pixels
left(90)        #pivote à gauche de 90°
forward(20)
right(30)
forward(200)