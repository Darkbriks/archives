﻿from turtle import *

listeCouleurs=['purple', 'blue', 'yellow', 'green', 'red']

def trace_cercle(rayon):
    circle(rayon)

