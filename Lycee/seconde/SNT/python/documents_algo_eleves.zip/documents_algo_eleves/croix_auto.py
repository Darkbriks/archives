﻿from turtle import * #importation du module turtle

#définition de la fonction trait utilisation un paramètre longueur
def trait(longueur):
    forward (longueur)
    right(90)

def tracer_croix(longueur):
    #boucle permettant le tracer de chacune des 4 branches
    for branche in range(4):
        left(180) #il faut faire faire demi-tour au curseur
        #boucle pour tracer les 3 traits composant une branche
        for k in range(3):
            trait(longueur)

