﻿from turtle import * #importation du module turtle

#définition de la fonction trait
def trait():
    forward (50)
    right(90)

