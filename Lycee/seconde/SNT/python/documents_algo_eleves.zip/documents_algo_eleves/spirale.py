﻿from turtle import *

def trace(longueur):
    """
        trace un segment puis fait pivoter le curseur
        :param longueur: (int) longueur du segment à tracer
    """
    forward(longueur)
    right(60)

def lancer():
    """
        lance le tracé de la spirale
        longueur initiale : 5 pixels
        longueur maximale : 400 pixels
        augmentation de la longueur de 5% à chaque tracé
    """
    longueur=5
