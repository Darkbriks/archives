#include <iostream>
using namespace std;

#include "types.hpp"
#include "fifo.hpp"
#include "matrices.hpp"
#include "parcours.hpp"
#include "dijkstra.hpp"

/**
 * Licence Informatique 2eme année - ULCO
 * correction du TP4 du module d'algorithmique
 * consacré aux graphes. Année 2023-2024
 * Auteur : C. Renaud
 */



/**
 * Fonction prinicpale permettant de tester le parcours en profondeur
 * d'un graphe, en utilisant un parcours récursif puis un parcours avec
 * une pile. L'application attend le nom d'un fichier contenant la description
 * d'un matrice d'adjacence pour pouvoir s'exécuter.
 */

int main(int argc, char *argv[]){
  
  if(argc!=3){
    cout << "Syntaxe : " << argv[0] << " <graphe> <numero du sommet de depart>" << endl;
    return -1;
  }

  // matrice d'adjacence du graphe à parcourir
  MatriceAdjacence mat={0, nullptr};
  int s = atoi(argv[2]);

  if(!charger(argv[1], mat)){
    cerr << "Erreur lors du chargement du fichier " << argv[1] << endl;
    return -1;
  }

  if(mat.ordre < s or s<0)
  {
    cerr << "Le sommet choisi n'est pas adequat :" << s << endl;
    return -1;
  }
  
  // affichage de la matrice pour contrôle
  cout << mat.ordre<<endl;
  afficher(mat);

  int sommet = atoi(argv[2]);
  Couleur *couleurs = new Couleur[mat.ordre];
  int *parents = new int[mat.ordre];
  int *distances = new int[mat.ordre];
  cheminVers(mat,s,couleurs,distances,parents);
  

  // affichage des chemins
  for(int i=0; i<mat.ordre; i++) { if (i != sommet)
  {
    cout << "chemin vers " << i << " (lg = " << distances[i] << ") = ";
    afficher_CheminVers(i, parents); cout << endl; }
  }
  // suppression des tableaux
  delete couleurs;
  delete parents;
  
  
  return 1;
}


