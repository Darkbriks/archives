﻿int sommetBlancMin(MatriceAdjacence mat, Couleur *coul, int *dist);
void cheminVers(MatriceAdjacence mat, int sommetDepart, Couleur *coul, int *dist, int *parent);
void afficher_CheminVers(int sf, int *parent);