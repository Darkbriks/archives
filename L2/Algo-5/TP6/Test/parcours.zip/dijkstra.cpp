﻿#include "types.hpp"
#include <iostream>
#include <iostream>

int sommetBlancMin(MatriceAdjacence mat, Couleur *coul, int *dist)
{
    int vmin = (int)INFINI; 
	int smin = INDEFINI;
    for (int i = 0; i < mat.ordre; i++)
    {
        if (coul[i] == BLANC && dist[i] < vmin)
        {
            vmin = dist[i]; smin = i;
        }
    }
    return smin;
}


void cheminVers(MatriceAdjacence mat, int sommetDepart, Couleur *coul, int *dist, int *parent)
{
    // Initialisation des tableaux
    for (int i = 0; i < mat.ordre; i++) { coul[i] = BLANC; dist[i] = (int)INFINI; parent[i] = INDEFINI; }
    dist[sommetDepart] = 0;
	bool t = true, n;
    while (t)
    {
        t = false; // On initialise t à false au début de chaque itération
        for (int i = 0; i < mat.ordre; i++)
        {
            if (coul[i] == BLANC)
            {
                t = true; // Si au moins un sommet blanc est trouvé, on continue la boucle
                break;
            }
        }

        if (!t) break; // Si aucun sommet blanc n'est trouvé, on sort de la boucle principale

        int u = sommetBlancMin(mat, coul, dist);

        for (int i = 0; i < mat.ordre; i++)
        {
		    bool n = false;
    		Maillon *ptr = mat.lignes[u];
    		while (ptr != nullptr) 
    		{ 
        		if (ptr->col == i) 
        		{
            		n = true; // Définir n à true si un voisin correspondant est trouvé
            		break; // Sortir de la boucle dès qu'un voisin est trouvé
        		}
        		ptr = ptr->suiv; 
    		}
    		if (n && coul[i] == BLANC)
        	{
				int w = int(INFINI);
    			Maillon *ptr = mat.lignes[u];
    			while (ptr != nullptr) 
				{ 
					if (ptr->col == i){ 
						w=  ptr->coef;
					}
	 			ptr = ptr->suiv; 
				}
            	if (dist[i] > dist[u] + w)
            	{
            		dist[i] = dist[u] + w;
                	parent[i] = u;
            	}
        	}
    	}
		coul[u] = NOIR;
    }
}


void afficher_CheminVers(int sommet, int *parent) { 
	if(parent[sommet]!=INDEFINI) { 
		afficher_CheminVers(parent[sommet], parent); 
	} 
	std::cout << sommet << " "; }





